import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';

import { AppComponent }  from './app.component';
import {CourseComponent} from './course.component';
import {ShoppingCartComponent} from './shoppingcart.component';
import {ProductComponent} from './product.component';

import {CutShortPipe} from './cutshort.pipe';

import {HoverDirective}from './hoverOnProducts.directive';

@NgModule({
  imports:      [ BrowserModule,FormsModule ],
  declarations: [ AppComponent,CourseComponent,
  ProductComponent,ShoppingCartComponent,
  CutShortPipe,HoverDirective ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
