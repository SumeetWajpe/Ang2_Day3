"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var CourseComponent = (function () {
    function CourseComponent() {
        //  @Input('name')    coursename:string='Unknown';
        //   @Input('url')   imageUrl:string='';
        //   price:number=0;
        //   location:string="Unknown";
        //   duration:string="Unknown";
        this.details = {};
    }
    __decorate([
        core_1.Input('coursedetails'), 
        __metadata('design:type', Object)
    ], CourseComponent.prototype, "details", void 0);
    CourseComponent = __decorate([
        core_1.Component({
            selector: 'course',
            //     template:`<h1> Getting Started With {{ coursename }}  ! </h1>
            //     <img src='{{ imageUrl }}' height="200xp" width="400px" />
            //    <img [src]='imageUrl'  height="200xp" width="400px" />`
            template: "\n<div class=\"Course\">\n<h1>  {{ details.name }}  ! </h1>\n    <img [src]='details.imageUrl'  height=\"100px\" width=\"100px\" />    \n   <p> <b>Location : {{ details.location}}  !</b> </p>\n  <p>   <b> Trainer: {{ details.trainer }}</b> </p>\n    \n    </div>\n    ",
            //     styles:[
            // `.Course{
            //   background-color:yellow;
            //   border:2px solid black;
            //   border-radius:20px;
            //   padding:20px;
            //   margin:10px;
            // }`], // OR 
            styleUrls: ['./app/courses.styles.css']
        }), 
        __metadata('design:paramtypes', [])
    ], CourseComponent);
    return CourseComponent;
}());
exports.CourseComponent = CourseComponent;
// 
//# sourceMappingURL=course.component.js.map