import {Directive,ElementRef,Input,HostListener} from '@angular/core';

@Directive({
    selector:'[productStyle]'
})
export class HoverDirective{
    @Input('productColor') passedColor:string="yellow";
    constructor(private refEle:ElementRef){
    }

    ngOnInit(){
        this.refEle.nativeElement.style.backgroundColor = this.passedColor;
    }

@HostListener('mouseenter') on_mouse_enter(){
    this.refEle.nativeElement.style.backgroundColor = "orange";
}
@HostListener('mouseleave') on_mouse_leave(){
    this.refEle.nativeElement.style.backgroundColor = this.passedColor;
}


}