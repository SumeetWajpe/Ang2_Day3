import {Component} from '@angular/core';


@Component({
    selector: 'shoppingcart',    
        // template:` `
        templateUrl:'./app/shoppingcart.html',
        styles:[`
       
        input.ng-pristine.ng-invalid{
            background-color:pink;
        }
        input.ng-dirty.ng-valid{
            background-color:lightgreen;
        }
        input.ng-dirty.ng-invalid{
            border:2px solid red;
        }
        
        
        `]
})
export class ShoppingCartComponent {
   heading:string = 'Shopping Cart ';
   isSuccess:boolean=false;
   clr:string = "blue";
   borderColor:string = "red";
   productToBeSearched:string="";
   newProduct:any={};
    products: any[] = [
        {
            name: 'Lappy', price: 50000, quantity: 100, rating: 4, launchdate: new Date() ,available:true,description:`Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"`   },
        { name: 'LED TV', price: 25000, quantity: 10, rating: 3.4587, launchdate: new Date(), available: true,description:`Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"`  },
        { name: 'Desktop', price: 10000, quantity: 200, rating: 3, launchdate: new Date(), available: false ,description:`Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"`  },
        { name: 'Mobile', price: 20000, quantity: 1000, rating: 5, launchdate: new Date(), available: true,description:`Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"`  },
        { name: 'Camera', price: 90000, quantity: 10, rating: 4, launchdate: new Date(), available: true,description:`Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"`   }
     ];  


    HandleOnClick(){
        this.heading = " Welcome to Shopping Cart !";
    }

    onChangeHandler(e:any){
            let valueFromTxt = e.target.value;
            this.heading = valueFromTxt;
    }

    onFormSubmit(e:any,passedForm:any){

let newProductToBeAdded ={
    name:this.newProduct.name,
    price:this.newProduct.price,
    rating:this.newProduct.rating,
    quantity:this.newProduct.quantity    
};

if(passedForm.valid){
         this.products.push(newProductToBeAdded);
}

    }

}