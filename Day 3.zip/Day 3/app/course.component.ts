import {Component,Input} from '@angular/core';
import {ICourse} from './iCourse.interface';

@Component({
    selector:'course',
//     template:`<h1> Getting Started With {{ coursename }}  ! </h1>
//     <img src='{{ imageUrl }}' height="200xp" width="400px" />
//    <img [src]='imageUrl'  height="200xp" width="400px" />`
template:`
<div class="Course">
<h1>  {{ details.name }}  ! </h1>
    <img [src]='details.imageUrl'  height="100px" width="100px" />    
   <p> <b>Location : {{ details.location}}  !</b> </p>
  <p>   <b> Trainer: {{ details.trainer }}</b> </p>
    
    </div>
    ` ,
//     styles:[
// `.Course{
//   background-color:yellow;
//   border:2px solid black;
//   border-radius:20px;
//   padding:20px;
//   margin:10px;
// }`], // OR 
    styleUrls:['./app/courses.styles.css']
  })
export class CourseComponent{
    //  @Input('name')    coursename:string='Unknown';
    //   @Input('url')   imageUrl:string='';
    //   price:number=0;
    //   location:string="Unknown";
    //   duration:string="Unknown";

    @Input('coursedetails') details:ICourse={};
}

//